@extends('layout')

@section('main')
    <h1>M4 POS System</h1>
    <div><a href="/item">Items</a></div>
    <div><a href="/customer">Customers</a></div>
      {{-- <div><a href="/invoices">Invoices</a></div> --}}

@endsection