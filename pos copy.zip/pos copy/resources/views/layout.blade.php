<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POS System</title>
</head>
<body>
    @yield('main')
</body>
</html>